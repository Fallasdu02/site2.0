<?php
require_once 'assets/php/includes/auth_check.php';
require_once 'assets/php/config/config.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
  header("Location: dashboard_users.php");
  exit;
}

$userId = intval($_GET['id']);

try {
  // Charger les infos utilisateur
  $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
  $stmt->execute([$userId]);
  $user = $stmt->fetch(PDO::FETCH_ASSOC);

  if (!$user) {
    header("Location: dashboard_users.php");
    exit;
  }

  // Si formulaire soumis
  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $prenom = $_POST['prenom'] ?? '';
    $email = $_POST['email'] ?? '';

    // Mise à jour
    $stmt = $pdo->prepare("UPDATE users SET prenom = ?, email = ? WHERE id = ?");
    $stmt->execute([$prenom, $email, $userId]);
    $_SESSION['flash_success'] = "✅ Utilisateur modifié avec succès.";
    header("Location: dashboard_users.php");
    exit;
  }

} catch (PDOException $e) {
  $error = "Erreur : " . $e->getMessage();
}
?>

<?php require_once 'assets/php/includes/header.php'; ?>

<div class="container py-5">
  <h2 class="mb-4">✏️ Modifier l’utilisateur</h2>

  <?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= $error ?></div>
  <?php endif; ?>

  <form method="POST" class="needs-validation" novalidate>
    <div class="mb-3">
      <label for="prenom" class="form-label">Nom</label>
      <input type="text" class="form-control" name="prenom" id="prenom" value="<?= htmlspecialchars($user['prenom']) ?>" required>
    </div>

    <div class="mb-3">
      <label for="email" class="form-label">Email</label>
      <input type="email" class="form-control" name="email" id="email" value="<?= htmlspecialchars($user['email']) ?>" required>
    </div>

    <button type="submit" class="btn btn-primary">💾 Enregistrer</button>
    <a href="dashboard_users.php" class="btn btn-secondary">↩️ Annuler</a>
  </form>
</div>

<?php require_once 'assets/php/includes/footer.php'; ?>
