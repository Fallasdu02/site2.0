<?php
require_once 'assets/php/includes/auth_check.php';
require_once 'assets/php/config/config.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
  header("Location: dashboard_articles.php");
  exit;
}

$articleId = (int) $_GET['id'];

try {
  $stmt = $pdo->prepare("DELETE FROM articles WHERE id = ?");
  $stmt->execute([$articleId]);

  $_SESSION['flash_success'] = "🗑️ Article supprimé avec succès.";
} catch (PDOException $e) {
  // loguer l’erreur si besoin
}

header("Location: dashboard_articles.php");
exit;
