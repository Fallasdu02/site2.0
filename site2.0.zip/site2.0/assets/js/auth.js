document.addEventListener("DOMContentLoaded", () => {
  // Toggle mot de passe (inscription + login)
  document.querySelectorAll(".toggle-password").forEach((icon) => {
    icon.addEventListener("click", (e) => {
      e.stopPropagation(); // Empêche que ce clic ne soit intercepté par d'autres listeners
      const target = icon.dataset.target || icon.closest(".input-box")?.querySelector("input");
      const input = typeof target === "string" ? document.querySelector(target) : target;
      if (!input) return;
      const isPassword = input.type === "password";
      input.type = isPassword ? "text" : "password";
      icon.classList.toggle("bx-show", !isPassword);
      icon.classList.toggle("bx-hide", isPassword);
    });
  });

  // Vérifie si les deux mots de passe correspondent (inscription)
  const pwd1 = document.querySelector("#register-password");
  const pwd2 = document.querySelector("#confirm-password");
  const msg = document.querySelector("#password-match");
  if (pwd1 && pwd2 && msg) {
    const checkMatch = () => {
      msg.classList.toggle("d-none", pwd1.value === pwd2.value);
    };
    pwd1.addEventListener("input", checkMatch);
    pwd2.addEventListener("input", checkMatch);
  }

  // Validation Bootstrap
  document.querySelectorAll(".needs-validation").forEach((form) => {
    form.addEventListener("submit", (event) => {
      if (!form.checkValidity()) {
        event.preventDefault();
        event.stopPropagation();
      }
      form.classList.add("was-validated");
    });
  });

  // Auth modal show/hide
  const authModal = document.querySelector(".auth-modal");
  const connLink = document.querySelector(".conn-link");
  const loginLink = document.querySelector(".login-link");
  const registerLink = document.querySelector(".register-link");

  if (connLink && authModal) {
    connLink.addEventListener("click", (e) => {
      e.preventDefault();
      authModal.classList.add("show");
      authModal.classList.remove("slide");
    });
  }

  if (registerLink && authModal) {
    registerLink.addEventListener("click", (e) => {
      e.preventDefault();
      authModal.classList.add("slide");
    });
  }

  if (loginLink && authModal) {
    loginLink.addEventListener("click", (e) => {
      e.preventDefault();
      authModal.classList.remove("slide");
    });
  }

  // Fermer la modale via toutes les croix
  document.querySelectorAll(".close-btn-modal").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation(); // Empêche le clic de se propager vers les autres listeners
      // Ici, on redirige vers index.php, ce qui remplace la simple fermeture.
      window.location.href = 'index.php';
    });
  });

  // Fermer la modale si clic en dehors de .form-box et hors de .conn-link
  document.addEventListener("click", (e) => {
    if (
      authModal?.classList.contains("show") &&
      !e.target.closest(".form-box") &&
      !e.target.closest(".conn-link") &&
      // On ignore le clic sur le close button pour ne pas déclencher le listener global.
      !e.target.closest(".close-btn-modal")
    ) {
      authModal.classList.remove("show", "slide");
    }
  });

  // Ouvre automatiquement si #auth présent
  if (window.location.hash === "#auth" && authModal) {
    authModal.classList.add("show");
  }
});
