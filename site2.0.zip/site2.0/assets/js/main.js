document.addEventListener("DOMContentLoaded", () => {
  // Navbar mobile : refermer au clic sur lien
  document.querySelectorAll(".navbar-nav .nav-link").forEach((link) => {
    link.addEventListener("click", () => {
      const navbarCollapse = document.getElementById("navbarNav");
      if (navbarCollapse?.classList.contains("show")) {
        new bootstrap.Collapse(navbarCollapse, { toggle: false }).hide();
      }
    });
  });

  // Bouton retour en haut
  const backBtn = document.querySelector(".back-to-top");
  const toggleBackBtn = () => {
    if (backBtn) {
      backBtn.classList.toggle("d-none", window.pageYOffset < 300);
    }
  };

  if (backBtn) {
    window.addEventListener("scroll", toggleBackBtn);
    backBtn.addEventListener("click", (e) => {
      e.preventDefault();
      window.scrollTo({ top: 0, behavior: "smooth" });
    });
  }

  // Cookie Banner + Feedback
  const banner = document.getElementById("cookieBanner");
  const feedback = document.getElementById("cookieFeedback");

  const showCookieMessage = (text, type = "info") => {
    if (!feedback) return;
    feedback.textContent = text;
    feedback.className = `alert alert-${type} position-fixed bottom-0 end-0 m-3`;
    feedback.classList.remove("d-none");
    setTimeout(() => feedback.classList.add("d-none"), 4000);
  };

  if (localStorage.getItem("cookieConsent") && banner) {
    banner.style.display = "none";
  }

  const accept = document.querySelector(".cookie-accept");
  const decline = document.querySelector(".cookie-decline");
  const settings = document.querySelector(".cookie-settings");

  accept?.addEventListener("click", () => {
    localStorage.setItem("cookieConsent", "accepted");
    if (banner) banner.style.display = "none";
    showCookieMessage("Vous avez accepté les cookies", "success");
  });

  decline?.addEventListener("click", () => {
    localStorage.setItem("cookieConsent", "declined");
    if (banner) banner.style.display = "none";
    showCookieMessage("Vous avez refusé les cookies", "danger");
  });

  settings?.addEventListener("click", () => {
    showCookieMessage("Paramètres non disponibles pour le moment", "warning");
  });

  // Formulaire de contact avec validation
  const contactForm = document.getElementById("contactForm");
  contactForm?.addEventListener("submit", (e) => {
    if (!contactForm.checkValidity()) {
      e.preventDefault();
      e.stopPropagation();
    }
    contactForm.classList.add("was-validated");
  });
});
