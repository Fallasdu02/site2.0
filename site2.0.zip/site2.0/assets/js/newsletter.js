document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("newsletterForm");
  const success = document.getElementById("successPopup");

  // Validation + Feedback visuel
  if (form && success) {
form.addEventListener("submit", (e) => {
  e.preventDefault();

  if (!form.checkValidity()) {
    e.stopPropagation();
  } else {
    success.innerHTML = `<span class="success-icon">✔</span> Vous vous êtes inscrit à la newsletter.<br>Pour vous désinscrire, veuillez utiliser le lien dans vos mails.`;
    success.classList.remove("d-none");
    success.classList.add("fade-in");

    // Cacher après 5 secondes
    setTimeout(() => {
      success.classList.add("d-none");
      success.classList.remove("fade-in");
    }, 5000);
  }

  form.classList.add("was-validated");
});
  }
});
