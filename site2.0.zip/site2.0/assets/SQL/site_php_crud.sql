DROP DATABASE IF EXISTS site_php_crud;
CREATE DATABASE site_php_crud;
USE site_php_crud;


CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nom VARCHAR(100),
  prenom VARCHAR(100),
  email VARCHAR(150) UNIQUE NOT NULL,
  mot_de_passe VARCHAR(255) NOT NULL,
  role ENUM('admin', 'user') DEFAULT 'user',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);


CREATE TABLE sections (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nom VARCHAR(100)
);


CREATE TABLE articles (
  id INT AUTO_INCREMENT PRIMARY KEY,
  titre VARCHAR(255) NOT NULL,
  contenu TEXT NOT NULL,
  categorie VARCHAR(100) DEFAULT 'blog',
  image VARCHAR(255),
  id_auteur INT,
  id_section INT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (id_auteur) REFERENCES users(id),
  FOREIGN KEY (id_section) REFERENCES sections(id)
);


CREATE TABLE commentaires (
  id INT AUTO_INCREMENT PRIMARY KEY,
  contenu TEXT NOT NULL,
  id_user INT,
  id_article INT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (id_user) REFERENCES users(id),
  FOREIGN KEY (id_article) REFERENCES articles(id)
);


CREATE TABLE likes (
  id_user INT,
  id_article INT,
  PRIMARY KEY (id_user, id_article),
  FOREIGN KEY (id_user) REFERENCES users(id),
  FOREIGN KEY (id_article) REFERENCES articles(id)
);


INSERT INTO users (nom, prenom, email, mot_de_passe, role) VALUES
('Durand', 'Chloé', 'admin@example.com', '$2y$10$PikEgxh7Qk4rFkQIFU3AoeMgWihFS/W26kXUM6AvxtuzpmwDTRMT6', 'admin'),
('Bernard', 'Lucas', 'lucas@example.com', '$2y$10$OzD6TPuOJNUVY6ThNHze0.1MDkUQdmVcYB8d3aK29aB0YjeqHOZPq', 'user');


INSERT INTO sections (nom) VALUES ('Actualités'), ('Sport'), ('Culture'), ('Tech');


INSERT INTO articles (titre, contenu, id_auteur, id_section) VALUES
('Bienvenue sur notre nouveau site !',
'Nous sommes ravis de vous accueillir. Restez à l’écoute pour toutes les actualités du club.',
1, 1);


INSERT INTO commentaires (contenu, id_user, id_article) VALUES
('Bravo pour ce nouveau site !', 2, 1);


INSERT INTO likes (id_user, id_article) VALUES (2, 1);
--Email : admin@example.com

--Mot de passe : adminadmin (bcrypté)

--Ou comme simple user : lucas@example.com / useruser