<?php if (isset($_SESSION['flash'])): ?>
  <div class="alert alert-<?= $_SESSION['flash']['type'] ?>">
    <?= $_SESSION['flash']['message'] ?>
    <?php unset($_SESSION['flash']); ?>
  </div>
<?php endif; ?>
