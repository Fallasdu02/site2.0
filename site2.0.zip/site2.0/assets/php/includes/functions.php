<?php
function setFlash($message, $type = 'success') {
  $_SESSION['flash'] = [
    'message' => $message,
    'type' => $type
  ];
}
