<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$user = $_SESSION['user'] ?? null;
$isAdmin = $user && ($user['role'] === 'admin');
?>

<header>
  <nav class="navbar navbar-expand-lg shadow-sm">
    <div class="container-fluid">
      <a class="navbar-brand" href="index.php">
        <img src="./assets/img/logo-bchm.png" alt="logo BCHM" height="40">
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item"><a class="nav-link" href="index.php">Accueil</a></li>
          <li class="nav-item"><a class="nav-link" href="about.php">À propos</a></li>
          <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
          <li class="nav-item"><a class="nav-link" href="login.php">Se connecter</a></li>
          <li class="nav-item"><a class="nav-link" href="register.php">S'inscrire</a></li>

          <?php if ($user): ?>
            <?php if ($isAdmin): ?>
              <li class="nav-item"><a class="nav-link" href="dashboard_users.php">Utilisateurs</a></li>
              <li class="nav-item"><a class="nav-link" href="dashboard_articles.php">Articles</a></li>
            <?php else: ?>
              <li class="nav-item"><a class="nav-link" href="dashboard.php">Tableau de bord</a></li>
            <?php endif; ?>
            <li class="nav-item">
              <a class="nav-link disabled"><?= htmlspecialchars($user['prenom']) ?> (<?= $user['role'] ?>)</a>
            </li>
            <li class="nav-item"><a class="nav-link text-danger" href="logout.php">Déconnexion</a></li>
          <?php else: ?>
          <?php endif; ?>
        </ul>
      </div>
    </div>
  </nav>
</header>