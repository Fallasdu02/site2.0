<!-- ============================= -->
<!--       SECTION NEWSLETTER      -->
<!-- ============================= -->
<section class="container-fluid my-5 text-center">
  <h2 class="mb-3">Abonnez-vous à notre Newsletter</h2>
  <p>Recevez les dernières mises à jour directement dans votre boîte mail !</p>
  <a href="newsletter.php" target="_blank" class="btn btn-success">S'inscrire</a>
</section>
