<!-- ============================= -->
<!--         SÉPARATEUR HR        -->
<!-- ============================= -->
<div class="container-fluid">
  <hr class="custom-separator my-5">
</div>
