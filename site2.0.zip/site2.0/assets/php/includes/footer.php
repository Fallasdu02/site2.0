<footer class="footer-section">
  <div class="container-fluid">
    <div class="row text-center text-md-justify">
      <!-- À propos -->
      <div class="col-12 col-md-4">
        <h4>À propos</h4>
        <p>Notre club forme et accompagne les passionnés de basket dans leur progression.</p>
      </div>

      <!-- Liens utiles -->
      <div class="col-12 col-md-4">
        <h4>Liens utiles</h4>
        <ul class="list-unstyled">
          <li><a href="#">Mentions légales</a></li>
          <li><a href="#">Politique de confidentialité</a></li>
          <li><a href="#">Conditions d’utilisation</a></li>
        </ul>
      </div>

      <!-- Réseaux sociaux -->
      <div class="col-12 col-md-4">
        <h4>Suivez-nous</h4>
        <div class="social-icons">
          <a href="#"><i class="fab fa-facebook"></i></a>
          <a href="#"><i class="fab fa-twitter"></i></a>
          <a href="#"><i class="fab fa-instagram"></i></a>
        </div>
      </div>
    </div>

    <!-- Logo et copyright -->
    <div class="row mt-4 text-center">
      <div class="col-12">
        <img src="assets/img/logo-bchm.png" alt="Logo Club" class="footer-logo">
        <p class="mt-3">&copy; 2025 Tous droits réservés - BCHM.fr - Propulsé par RudyDev</p>
      </div>
    </div>
  </div>
</footer>

<!-- Back to Top -->
<a href="#" class="back-to-top d-none">
  <i class='bx  bxs-arrow-up' style="line-height: 0;"></i> 
</a>

<!-- Cookie Banner -->
<div id="cookieBanner" class="cookie-banner">
  <div class="cookie-container container-fluid">
    <p class="cookie-message">
      Nous utilisons des cookies pour améliorer votre expérience sur notre site et proposer des contenus adaptés. En poursuivant votre navigation, vous acceptez notre utilisation des cookies.
    </p>
    <div class="cookie-buttons">
      <button class="btn btn-secondary cookie-settings">Paramètres des cookies</button>
      <button class="btn btn-danger cookie-decline">Tout refuser</button>
      <button class="btn btn-success cookie-accept">Autoriser tous les cookies</button>
    </div>
  </div>
</div>

<!-- Cookie feedback toast -->
<div id="cookieFeedback" class="position-fixed bottom-0 end-0 m-3 alert alert-info d-none" role="alert" style="z-index: 11000;"></div>

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" defer></script>
<script src="/site2.0/assets/js/main.js" defer></script>
<script src="/site2.0/assets/js/auth.js" defer></script>
<script src="/site2.0/assets/js/newsletter.js" defer></script>
</body>
</html>
