<?php
if (session_status() === PHP_SESSION_NONE) {
  session_start();
}
if (!isset($pageTitle)) $pageTitle = "BCHM";
if (!isset($customStyle)) $customStyle = null;
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?= htmlspecialchars($pageTitle) ?> - BCHM</title>

  <!-- Meta SEO -->
  <meta name="description" content="Bienvenue sur le site du Basket Club Hayange-Marspich (BCHM). Découvrez nos actualités, nos équipes et vivez votre passion du basket !" />
  <meta name="keywords" content="BCHM, Basket Club Hayange-Marspich, basket, sport, actualités, équipes, U21, U18, U15, U13" />
  <meta name="author" content="RudyDev" />
  <meta name="theme-color" content="#000000" />
  <meta name="robots" content="index, follow" />
  <link rel="canonical" href="https://www.bchm.fr/" />

  <!-- Favicon -->
  <link rel="icon" href="assets/img/logo-bchm.png" type="image/x-icon" />

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet" />

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />

  <!-- Icon Fonts -->
  <script src="https://kit.fontawesome.com/df198b0cea.js" crossorigin="anonymous"></script>
  <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet" />

  <!-- Feuilles de style -->
  <link rel="stylesheet" href="assets/css/style.css" />
  <link rel="stylesheet" href="assets/css/style_dashboard.css" />
  <?php if ($customStyle): ?>
    <link rel="stylesheet" href="<?= htmlspecialchars($customStyle) ?>" />
  <?php endif; ?>

  <!-- Scripts globaux -->
  <script src="assets/js/main.js" defer></script>
  <script src="assets/js/auth.js" defer></script>
  <script src="assets/js/newsletter.js" defer></script>
</head>
<body>

