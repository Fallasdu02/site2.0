<!-- ============================= -->
<!--        SECTION SPONSORS       -->
<!-- ============================= -->
<section class="sponsors-section py-5">
  <div class="container-fluid">
    <h3 class="mb-4 text-center">Nos partenaires</h3>
    <div class="row justify-content-center g-4">
      <?php
      $sponsors = [
        ["src" => "assets/img/madinbasket-logo-1559140287.jpg.png", "alt" => "Partenaire 1"],
        ["src" => "assets/img/Unibet_logo.svg.png", "alt" => "Partenaire 2"],
        ["src" => "assets/img/logo-credit-mutuel.svg", "alt" => "Partenaire 3"],
        ["src" => "assets/img/bella-ciao.png", "alt" => "Partenaire 4"]
      ];
      foreach ($sponsors as $sp):
      ?>
        <div class="col-6 col-md-3 sponsors-logo text-center">
          <img src="<?= $sp['src'] ?>" alt="<?= $sp['alt'] ?>" class="img-fluid">
        </div>
      <?php endforeach; ?>
    </div>
    <h4 class="mt-5 text-center">Avec le soutien de :</h4>
    <div class="row justify-content-center g-4 mt-2">
      <div class="col-6 col-md-4 sponsors-logo text-center">
        <img src="assets/img/CMBBfondblanc.png" alt="Soutien 1" class="img-fluid">
      </div>
      <div class="col-6 col-md-4 sponsors-logo text-center">
        <img src="assets/img/Logo_FFBB_2010.svg.png" alt="Soutien 2" class="img-fluid">
      </div>
    </div>
  </div>
</section>
