<?php if (isset($_SESSION['auth_error'])): ?>
  <div class="alert alert-danger text-center mt-2"><?= $_SESSION['auth_error']; unset($_SESSION['auth_error']); ?></div>
<?php endif; ?>


<!-- auth_modal.php -->
<div class="auth-modal" id="authModal">
  <button type="button" class="close-btn-modal">&times;</button>

  <!-- ALERTE BOX -->
  <?php include 'alert_box.php'; ?>

  <!-- Login Form -->
  <div class="form-box login">
    <h2>Login</h2>
    <form action="auth_process.php" method="POST" class="needs-validation" novalidate>
      <div class="input-box">
        <input type="email" name="email" placeholder="Email" required />
        <i class="bx bxs-envelope"></i>
        <div class="invalid-feedback">Veuillez entrer un email valide.</div>
      </div>

      <div class="input-box">
        <input type="password" name="password" placeholder="Mot de passe" required id="login-password" />
        <i class="bx bxs-lock"></i>
        <i class="toggle-password bx bx-show" data-target="#login-password"></i>
        <div class="invalid-feedback">Veuillez entrer votre mot de passe.</div>
      </div>

      <div class="form-check remember-me">
        <input class="form-check-input" type="checkbox" name="remember" id="remember">
        <label class="form-check-label" for="remember">Se souvenir de moi</label>
      </div>

      <button type="submit" name="login_btn" class="btn">Login</button>
    </form>
    <p>Don't have an account? <a href="#" class="register-link">Register</a></p>
  </div>

  <!-- Register Form -->
  <div class="form-box register">
    <h2>Register</h2>
    <form action="assets/php/auth/auth_process.php" method="POST" class="needs-validation" novalidate>
      <div class="input-box">
        <input type="text" name="name" placeholder="Nom complet" required />
        <i class="bx bxs-user"></i>
        <div class="invalid-feedback">Veuillez entrer votre nom.</div>
      </div>

      <div class="input-box">
        <input type="email" name="email" placeholder="Email" required />
        <i class="bx bxs-envelope"></i>
        <div class="invalid-feedback">Veuillez entrer un email valide.</div>
      </div>

      <div class="input-box">
        <input type="password" name="password" placeholder="Mot de passe" required id="register-password" />
        <i class="bx bxs-lock"></i>
        <i class="toggle-password bx bx-show" data-target="#register-password"></i>
        <div class="invalid-feedback">Veuillez entrer un mot de passe.</div>
      </div>

      <div class="input-box">
        <input type="password" name="confirm_password" placeholder="Confirmez le mot de passe" required id="confirm-password" />
        <i class="bx bxs-lock"></i>
        <i class="toggle-password bx bx-show" data-target="#confirm-password"></i>
        <div class="invalid-feedback">Veuillez confirmer votre mot de passe.</div>
        <small id="password-match" class="text-danger ms-1 d-none">Les mots de passe ne correspondent pas.</small>
      </div>

      <button type="submit" name="register_btn" class="btn">Register</button>
    </form>
    <p>Already have an account? <a href="#" class="login-link">Login</a></p>
  </div>
</div>


