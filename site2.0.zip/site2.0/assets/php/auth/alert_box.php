<?php
if (!empty($_SESSION['auth_error'])) {
  echo '<div class="alert-box">
    <div class="alert error">
      <i class="bx bxs-x-circle"></i>
      <span>' . $_SESSION['auth_error'] . '</span>
    </div>
  </div>';
  unset($_SESSION['auth_error']);
}
?>

<?php if (!empty($alerts)): ?>
  <div class="alert-box">
    <?php foreach ($alerts as $alert): ?>
      <div class="alert <?= $alert['type']; ?>">
        <i class="bx <?= $alert['type'] === 'success' ? 'bxs-check-circle' : 'bxs-x-circle'; ?>"></i>
        <span><?= $alert['message']; ?></span>
      </div>
    <?php endforeach; ?>
  </div>
<?php endif; ?>
