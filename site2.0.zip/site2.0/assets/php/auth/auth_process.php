<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/site2.0/assets/php/config/config.php';


// Nettoyage
function clean($value): string {
  return htmlspecialchars(trim($value));
}

// INSCRIPTION
if (isset($_POST['register_btn'])) {
  $name     = clean($_POST['name']);
  $email    = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);
  $password = $_POST['password'];

  if ($name && $email && strlen($password) >= 6) {
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->execute([$email]);

    if ($stmt->rowCount() === 0) {
      $hash = password_hash($password, PASSWORD_DEFAULT);

      $insert = $pdo->prepare("INSERT INTO users (prenom, email, mot_de_passe) VALUES (?, ?, ?)");
      $insert->execute([$name, $email, $hash]);

      $_SESSION['user'] = [
        'id'     => $pdo->lastInsertId(),
        'prenom' => $name,
        'email'  => $email,
        'role'   => 'user'
      ];

      header("Location: /site2.0/dashboard.php");
      exit;
    } else {
      $_SESSION['auth_error'] = "Email déjà enregistré.";
      header("Location: /site2.0/index.php#auth");
      exit;
    }
  } else {
    $_SESSION['auth_error'] = "Champ invalide ou mot de passe trop court.";
    header("Location: /site2.0/index.php#auth");
    exit;
  }
}

// CONNEXION
if (isset($_POST['login_btn'])) {
  $email    = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);
  $password = $_POST['password'];

  if ($email && $password) {
    $stmt = $pdo->prepare("SELECT id, prenom, email, mot_de_passe, role FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['mot_de_passe'])) {
      $_SESSION['user'] = [
        'id'     => $user['id'],
        'prenom' => $user['prenom'],
        'email'  => $user['email'],
        'role'   => $user['role'] ?? 'user'
      ];

      header("Location: /site2.0/dashboard.php");
      exit;
    } else {
      $_SESSION['auth_error'] = "Email ou mot de passe incorrect.";
      header("Location: /site2.0/index.php#auth");
      exit;
    }
  } else {
    $_SESSION['auth_error'] = "Veuillez remplir tous les champs.";
    header("Location: /site2.0/index.php#auth");
    exit;
  }
}
