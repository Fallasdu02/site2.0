<?php
require_once 'assets/php/includes/auth_check.php';
require_once 'assets/php/config/config.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
  header("Location: dashboard_articles.php");
  exit;
}

$articleId = (int) $_GET['id'];
$error = null;

try {
  $stmt = $pdo->prepare("SELECT * FROM articles WHERE id = ?");
  $stmt->execute([$articleId]);
  $article = $stmt->fetch();

  if (!$article) {
    header("Location: dashboard_articles.php");
    exit;
  }

} catch (PDOException $e) {
  $error = "Erreur : " . $e->getMessage();
}
?>

<?php require_once 'assets/php/includes/header.php'; ?>

<div class="container py-5">
  <a href="dashboard_articles.php" class="btn btn-secondary mb-4">↩️ Retour</a>

  <?php if ($error): ?>
    <div class="alert alert-danger"><?= $error ?></div>
  <?php else: ?>
    <h2><?= htmlspecialchars($article['titre']) ?></h2>
    <p class="text-muted">
      📁 <?= htmlspecialchars($article['categorie']) ?> —
      🗓️ <?= date("d/m/Y à H:i", strtotime($article['created_at'])) ?>
    </p>
    <hr>
    <div class="mt-4">
      <?= nl2br(htmlspecialchars($article['contenu'])) ?>
    </div>
  <?php endif; ?>
</div>

<?php require_once 'assets/php/includes/footer.php'; ?>
