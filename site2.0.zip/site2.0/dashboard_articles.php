<?php
require_once 'assets/php/includes/auth_check.php';
$pageTitle = "Articles";
$customStyle = "style_dashboard.css";
require_once 'assets/php/config/config.php';
require_once 'assets/php/includes/header.php';
// require_once 'assets/php/includes/navbar_dashboard.php';
require_once 'assets/php/includes/header.php';
require_once 'assets/php/includes/navbar.php';

// --- Pagination ---
$limit = 10;
$page = isset($_GET['page']) ? max((int)$_GET['page'], 1) : 1;
$offset = ($page - 1) * $limit;

// --- Recherche ---
$search = $_GET['search'] ?? '';
$searchSql = '';
$params = [];

// --- Filtrage catégorie ---
$filterCategorie = $_GET['categorie'] ?? '';
$categorieSql = '';

if (!empty($search)) {
  $searchSql = "AND titre LIKE :search";
  $params[':search'] = "%$search%";
}

if (!empty($filterCategorie) && in_array($filterCategorie, ['blog','match','communiqué','evenement'])) {
  $categorieSql = "AND categorie = :categorie";
  $params[':categorie'] = $filterCategorie;
}

try {
  // Nombre total (pour pagination)
  $countStmt = $pdo->prepare("SELECT COUNT(*) FROM articles WHERE 1=1 $searchSql $categorieSql");
  $countStmt->execute($params);
  $totalArticles = $countStmt->fetchColumn();
  $totalPages = ceil($totalArticles / $limit);

  // Articles paginés
  $stmt = $pdo->prepare("SELECT id, titre, categorie, created_at FROM articles WHERE 1=1 $searchSql $categorieSql ORDER BY created_at DESC LIMIT :limit OFFSET :offset");
  foreach ($params as $key => $value) {
    $stmt->bindValue($key, $value);
  }
  $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
  $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
  $stmt->execute();
  $articles = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
  $articles = [];
  $error = "Erreur lors de la récupération des articles : " . $e->getMessage();
  $totalPages = 1;
}

?>

<div class="container-fluid">
  <div class="row">

    <!-- Sidebar -->
    <nav class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse border-end">
      <div class="position-sticky pt-3">
        <ul class="nav flex-column">
          <li class="nav-item"><a class="nav-link" href="dashboard.php">Accueil</a></li>
          <li class="nav-item"><a class="nav-link" href="dashboard_users.php">Utilisateurs</a></li>
          <li class="nav-item"><a class="nav-link active" href="dashboard_articles.php">Articles</a></li>
          <li class="nav-item"><a class="nav-link text-danger" href="logout.php">Déconnexion</a></li>
        </ul>
      </div>
    </nav>

    <!-- Contenu principal -->
    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
      <div class="d-flex justify-content-between align-items-center py-3 border-bottom">
        <h1 class="h2">📰 Gestion des articles</h1>
        <a href="add_article.php" class="btn btn-primary">➕ Ajouter un article</a>
      </div>

      <section class="mt-4">
        <?php if (!empty($_SESSION['flash_success'])): ?>
          <div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
            <?= $_SESSION['flash_success']; unset($_SESSION['flash_success']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fermer"></button>
          </div>
        <?php endif; ?>

        <form class="row mb-3" method="GET">
          <div class="col-md-6">
            <input type="text" name="search" class="form-control" placeholder="🔍 Rechercher un titre..." value="<?= htmlspecialchars($search) ?>">
          </div>
          <div class="col-md-3">
            <select name="categorie" class="form-select">
              <option value="">📁 Toutes les catégories</option>
              <option value="blog" <?= $filterCategorie === 'blog' ? 'selected' : '' ?>>📰 Blog</option>
              <option value="match" <?= $filterCategorie === 'match' ? 'selected' : '' ?>>🏀 Match</option>
              <option value="communiqué" <?= $filterCategorie === 'communiqué' ? 'selected' : '' ?>>📢 Communiqué</option>
              <option value="evenement" <?= $filterCategorie === 'evenement' ? 'selected' : '' ?>>📆 Événement</option>
            </select>
          </div>
          <div class="col-md-3">
            <button class="btn btn-outline-secondary w-100">Filtrer</button>
          </div>
        </form>

        <?php if (!empty($error)): ?>
          <div class="alert alert-danger"><?= $error ?></div>
        <?php endif; ?>

        <div class="table-responsive">
          <table class="table table-hover align-middle">
            <thead class="table-light">
              <tr>
                <th>#</th>
                <th>Titre</th>
                <th>Catégorie</th>
                <th>Publié le</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php if (!empty($articles)): ?>
                <?php foreach ($articles as $i => $article): ?>
                  <tr>
                    <td><?= ($offset + $i + 1) ?></td>
                    <td><?= htmlspecialchars($article['titre']) ?></td>
                    <td><?= htmlspecialchars($article['categorie']) ?></td>
                    <td><?= date("d/m/Y", strtotime($article['created_at'])) ?></td>
                    <td>
                        <a href="view_article.php?id=<?= $article['id'] ?>" class="btn btn-sm btn-outline-secondary">👁️ Voir</a>
                        <a href="edit_article.php?id=<?= $article['id'] ?>" class="btn btn-sm btn-outline-primary">✏️ Modifier</a>
                        <a href="delete_article.php?id=<?= $article['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Supprimer cet article ?');">🗑️ Supprimer</a>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php else: ?>
                <tr><td colspan="5" class="text-center text-muted">Aucun article trouvé.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>

        <?php if ($totalPages > 1): ?>
          <nav>
            <ul class="pagination justify-content-center mt-3">

              <!-- Précédent -->
              <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => max(1, $page - 1)])) ?>">« Précédent</a>
              </li>

              <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <li class="page-item <?= $i === $page ? 'active' : '' ?>">
                  <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $i])) ?>"><?= $i ?></a>
                </li>
              <?php endfor; ?>

              <!-- Suivant -->
              <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>">
                <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => min($totalPages, $page + 1)])) ?>">Suivant »</a>
              </li>
            </ul>
          </nav>
        <?php endif; ?>
      </section>
    </main>
  </div>
</div>

<?php require_once 'assets/php/includes/footer.php'; ?>
