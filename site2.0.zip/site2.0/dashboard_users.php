<?php
require_once 'assets/php/includes/auth_check.php';
$pageTitle = "Utilisateurs";
$customStyle = "style_dashboard.css";
require_once 'assets/php/config/config.php';
require_once 'assets/php/includes/header.php';
// require_once 'assets/php/includes/navbar_dashboard.php';
require_once 'assets/php/includes/header.php';
require_once 'assets/php/includes/navbar.php';

try {
  // Pagination : combien par page
  $limit = 10;
  $page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int) $_GET['page'] : 1;
  $offset = ($page - 1) * $limit;

  // Nombre total d’utilisateurs
  $stmt = $pdo->query("SELECT COUNT(*) FROM users");
  $totalUsers = (int) $stmt->fetchColumn();
  $totalPages = ceil($totalUsers / $limit);

  // Données paginées
  $stmt = $pdo->prepare("SELECT id, prenom, email, created_at FROM users ORDER BY created_at DESC LIMIT :limit OFFSET :offset");
  $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
  $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
  $stmt->execute();
  $users = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
  $users = [];
  $error = "Erreur lors de la récupération des utilisateurs : " . $e->getMessage();
  $totalPages = 1;
}



?>

<div class="container-fluid">
  <div class="row">
    <!-- Sidebar -->
    <nav class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse border-end">
      <div class="position-sticky pt-3">
        <ul class="nav flex-column">
          <li class="nav-item"><a class="nav-link" href="dashboard.php">🏠 Accueil</a></li>
          <li class="nav-item"><a class="nav-link active" href="#">👥 Utilisateurs</a></li>
          <li class="nav-item"><a class="nav-link" href="dashboard_articles.php">📰 Articles</a></li>
          <li class="nav-item"><a class="nav-link text-danger" href="logout.php">🚪 Déconnexion</a></li>
        </ul>
      </div>
    </nav>

    <!-- Contenu principal -->
    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
      <div class="d-flex justify-content-between align-items-center py-3 border-bottom">
        <h1 class="h2">👥 Gestion des utilisateurs</h1>
      </div>
        <?php if (!empty($_SESSION['flash_success'])): ?>
            <div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
                <?= $_SESSION['flash_success']; unset($_SESSION['flash_success']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fermer"></button>
            </div>
            <?php endif; ?>

      <section class="mt-4">
        <?php if (!empty($error)): ?>
          <div class="alert alert-danger"><?= $error ?></div>
        <?php endif; ?>

        <div class="table-responsive">
          <a href="add_user.php" class="btn btn-primary mb-3 me-2">➕ Ajouter un utilisateur</a>
          <a href="export_users_csv.php" class="btn btn-success mb-3">⬇️ Exporter CSV</a>
          <input type="text" id="searchInput" class="form-control mb-3" placeholder="🔍 Rechercher un utilisateur..." />

          <table class="table table-hover align-middle">
            <thead class="table-light">
              <tr>
                <th>#</th>
                <th>Nom</th>
                <th>Email</th>
                <th>Inscrit le</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php if (!empty($users)): ?>
                <?php foreach ($users as $i => $user): ?>
                  <tr>
                    <td><?= $i + 1 ?></td>
                    <td><?= htmlspecialchars($user['prenom']) ?></td>
                    <td><?= htmlspecialchars($user['email']) ?></td>
                    <td><?= date("d/m/Y", strtotime($user['created_at'])) ?></td>
                    <td>
                      <a href="edit_user.php?id=<?= $user['id'] ?>" class="btn btn-sm btn-outline-primary">✏️ Modifier</a>
                      <a href="delete_user.php?id=<?= $user['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Supprimer cet utilisateur ?');">🗑️ Supprimer</a>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php else: ?>
                <tr><td colspan="5" class="text-center text-muted">Aucun utilisateur trouvé.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
            <?php if ($totalPages > 1): ?>
            <nav>
                <ul class="pagination justify-content-center mt-3">

                <!-- Précédent -->
                <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                    <a class="page-link" href="?page=<?= max($page - 1, 1) ?>" tabindex="-1">« Précédent</a>
                </li>

                <!-- Pages numérotées -->
                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                    <li class="page-item <?= $i === $page ? 'active' : '' ?>">
                    <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
                    </li>
                <?php endfor; ?>

                <!-- Suivant -->
                <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>">
                    <a class="page-link" href="?page=<?= min($page + 1, $totalPages) ?>">Suivant »</a>
                </li>

                </ul>
            </nav>
            <?php endif; ?>
        </div>
      </section>
    </main>
  </div>
</div>

<script>
document.getElementById('searchInput').addEventListener('keyup', function () {
  const term = this.value.toLowerCase();
  document.querySelectorAll('tbody tr').forEach((row) => {
    row.style.display = row.textContent.toLowerCase().includes(term) ? '' : 'none';
  });
});
</script>

<?php require_once 'assets/php/includes/footer.php'; ?>
