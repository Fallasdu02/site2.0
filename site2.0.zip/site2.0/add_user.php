<?php
require_once 'assets/php/includes/auth_check.php';
require_once 'assets/php/config/config.php';

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $prenom = trim($_POST['prenom'] ?? '');
  $email = trim($_POST['email'] ?? '');

  if (empty($prenom) || empty($email)) {
    $error = "Tous les champs sont requis.";
  } else {
    try {
        // Vérifie si l'email existe déjà
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $exists = $stmt->fetchColumn();

        if ($exists) {
        $error = "❌ Cet email est déjà enregistré.";
        } else {
        // Ajoute l'utilisateur si l'email est libre
        $stmt = $pdo->prepare("INSERT INTO users (prenom, email, created_at) VALUES (?, ?, NOW())");
        $stmt->execute([$prenom, $email]);

        $_SESSION['flash_success'] = "✅ Utilisateur ajouté avec succès.";
        header("Location: dashboard_users.php");
        exit;
        }


      $_SESSION['flash_success'] = "✅ Utilisateur ajouté avec succès.";
      header("Location: dashboard_users.php");
      exit;

    } catch (PDOException $e) {
      $error = "Erreur : " . $e->getMessage();
    }
  }
}
?>

<?php require_once 'assets/php/includes/header.php'; ?>

<div class="container py-5">
  <h2 class="mb-4">➕ Ajouter un utilisateur</h2>

  <?php if ($error): ?>
    <div class="alert alert-danger"><?= $error ?></div>
  <?php endif; ?>

  <form method="POST" class="needs-validation" novalidate>
    <div class="mb-3">
      <label for="prenom" class="form-label">Nom</label>
      <input type="text" class="form-control" name="prenom" id="prenom" required>
    </div>

    <div class="mb-3">
      <label for="email" class="form-label">Email</label>
      <input type="email" class="form-control" name="email" id="email" required>
    </div>

    <button type="submit" class="btn btn-success">💾 Ajouter</button>
    <a href="dashboard_users.php" class="btn btn-secondary">↩️ Retour</a>
  </form>
</div>

<?php require_once 'assets/php/includes/footer.php'; ?>
