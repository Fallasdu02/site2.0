<?php
require_once 'assets/php/includes/auth_check.php';
require_once 'assets/php/config/config.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
  header("Location: dashboard_articles.php");
  exit;
}

$articleId = (int) $_GET['id'];
$error = null;

try {
  $stmt = $pdo->prepare("SELECT * FROM articles WHERE id = ?");
  $stmt->execute([$articleId]);
  $article = $stmt->fetch();

  if (!$article) {
    header("Location: dashboard_articles.php");
    exit;
  }

  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titre = trim($_POST['titre'] ?? '');
    $categorie = $_POST['categorie'] ?? 'blog';
    $contenu = trim($_POST['contenu'] ?? '');

    if (empty($titre) || empty($contenu)) {
      $error = "Titre et contenu sont obligatoires.";
    } else {
      $stmt = $pdo->prepare("UPDATE articles SET titre = ?, categorie = ?, contenu = ? WHERE id = ?");
      $stmt->execute([$titre, $categorie, $contenu, $articleId]);

      $_SESSION['flash_success'] = "✅ Article modifié avec succès.";
      header("Location: dashboard_articles.php");
      exit;
    }
  }

} catch (PDOException $e) {
  $error = "Erreur : " . $e->getMessage();
}
?>

<?php require_once 'assets/php/includes/header.php'; ?>

<div class="container py-5">
  <h2 class="mb-4">Modifier l’article</h2>

  <?php if ($error): ?>
    <div class="alert alert-danger"><?= $error ?></div>
  <?php endif; ?>

  <form method="POST">
    <div class="mb-3">
      <label for="titre" class="form-label">Titre</label>
      <input type="text" class="form-control" name="titre" id="titre" value="<?= htmlspecialchars($article['titre']) ?>" required>
    </div>

    <div class="mb-3">
      <label for="categorie" class="form-label">Catégorie</label>
      <select name="categorie" id="categorie" class="form-select">
        <?php
        $categories = ['blog' => '📰 Blog', 'match' => '🏀 Match', 'communiqué' => '📢 Communiqué', 'evenement' => '📆 Événement'];
        foreach ($categories as $key => $label) {
          $selected = $article['categorie'] === $key ? 'selected' : '';
          echo "<option value=\"$key\" $selected>$label</option>";
        }
        ?>
      </select>
    </div>

    <div class="mb-3">
      <label for="contenu" class="form-label">Contenu</label>
      <textarea name="contenu" id="contenu" class="form-control" rows="6" required><?= htmlspecialchars($article['contenu']) ?></textarea>
    </div>

    <button type="submit" class="btn btn-primary">Enregistrer</button>
    <a href="dashboard_articles.php" class="btn btn-secondary">↩️ Annuler</a>
  </form>
</div>

<?php require_once 'assets/php/includes/footer.php'; ?>
