
<?php
session_start();
$pageTitle = "Connexion";
$customStyle = null;
require_once './assets/php/includes/header.php';
require_once './assets/php/includes/navbar.php';
?>

<?php if (isset($_SESSION['auth_error'])): ?>
  <div class="alert alert-danger text-center"><?= $_SESSION['auth_error']; unset($_SESSION['auth_error']); ?></div>
<?php endif; ?>

<section class="container-fluid d-flex align-items-center justify-content-center" style="min-height: 100vh;">
  <div class="auth-modal show">

    <!-- Bouton de retour -->
    <button type="button" class="close-btn-modal" onclick="event.stopPropagation(); window.location.href='index.php'">&times;</button>


    <!-- Login Form -->
    <div class="form-box login">
      <h2>Login</h2>
      <form action="assets/php/auth/auth_process.php" method="POST" class="needs-validation" novalidate>

        <div class="input-box">
          <input type="email" name="email" placeholder="Email" required />
          <i class="bx bxs-envelope"></i>
          <div class="invalid-feedback">Veuillez entrer un email valide.</div>
        </div>

        <div class="input-box">
          <input type="password" name="password" placeholder="Mot de passe" required id="login-password" />
          <i class="bx bxs-lock"></i>
          <i class="toggle-password bx bx-show" data-target="#login-password"></i>
          <div class="invalid-feedback">Veuillez entrer votre mot de passe.</div>
        </div>

        <div class="form-check remember-me">
          <input class="form-check-input" type="checkbox" name="remember" id="remember">
          <label class="form-check-label" for="remember">Se souvenir de moi</label>
        </div>

        <button type="submit" name="login_btn" class="btn">
          <i class="bx bxs-log-in-circle"></i> Se connecter
        </button>
      </form>

      <p>Pas encore inscrit ? <a href="register.php">Créer un compte</a></p>
    </div>
  </div>
</section>

<?php
include 'assets/php/includes/hr_separator.php';
include 'assets/php/includes/newsletter_section.php';
include 'assets/php/includes/hr_separator.php'; 
include 'assets/php/includes/sponsors_section.php';
require_once 'assets/php/includes/footer.php';
?>