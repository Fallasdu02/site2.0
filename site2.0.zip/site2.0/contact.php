<?php
$pageTitle = "Contact";
require_once 'assets/php/includes/header.php';
require_once 'assets/php/includes/navbar.php';
?>

<?php include './assets/php/auth/alert_box.php';?>
<?php include './assets/php/auth/auth_modal.php';?>


  <section class="container my-5">
  <h1 class="text-center mb-4">Une question ? Un projet ? Envoyez-nous un message !</h1>
  
  <form id="contactForm" class="p-4 bg-light rounded shadow">
    <!-- NOM -->
    <div class="mb-3">
      <label for="nom" class="form-label">Nom *</label>
      <input type="text" class="form-control" id="nom" name="nom" required pattern="[A-Za-zÀ-ÿ\s]+" 
             placeholder="Entrez votre nom">
      <div class="invalid-feedback">Veuillez entrer un nom valide (sans chiffres).</div>
    </div>
    
    <!-- PRÉNOM -->
    <div class="mb-3">
      <label for="prenom" class="form-label">Prénom *</label>
      <input type="text" class="form-control" id="prenom" name="prenom" required pattern="[A-Za-zÀ-ÿ\s]+"
             placeholder="Entrez votre prénom">
      <div class="invalid-feedback">Veuillez entrer un prénom valide (sans chiffres).</div>
    </div>

    <!-- EMAIL -->
    <div class="mb-3">
      <label for="email" class="form-label">Email *</label>
      <input type="email" class="form-control" id="email" name="email" required 
             placeholder="exemple@domaine.com">
      <div class="invalid-feedback">Veuillez entrer un email valide avec "@".</div>
    </div>

    <!-- MESSAGE -->
    <div class="mb-3">
      <label for="message" class="form-label">Message *</label>
      <textarea class="form-control" id="message" name="message" rows="4" required 
                placeholder="Écrivez votre message ici..."></textarea>
      <div class="invalid-feedback">Veuillez entrer un message.</div>
    </div>

    <!-- CHECKBOX -->
    <div class="mb-3 form-check">
      <input type="checkbox" class="form-check-input" id="acceptPolicy" required>
      <label class="form-check-label" for="acceptPolicy">
        En cliquant, vous acceptez nos <a href="#">politiques de confidentialité</a>.
      </label>
      <div class="invalid-feedback">Vous devez accepter nos politiques.</div>
    </div>

    <!-- BOUTON SOUMISSION -->
    <div class="text-center">
      <button type="submit" class="btn btn-success">Envoyer</button>
    </div>
  </form>
</section>

<?php include './assets/php/includes/hr_separator.php'; ?>




<section class="container-fluid my-5">
  <h2 class="text-center mb-4">📍 Nos coordonnées</h2>
  
  <!-- Informations -->
  <div class="row text-center text-md-start align-items-center">
    <div class="col-md-4 text-center">
      <h4>🏠 Adresse</h4>
      <p>Cosec 98 Rue du 6 Juin 1944, 57700 Hayange</p>
    </div>
    <div class="col-md-4 text-center">
      <h4>📧 Email</h4>
      <p><a href="mailto:contact@bchm.fr">contact@bchm.fr</a></p>
    </div>
    <div class="col-md-4 text-center">
      <h4>📞 Téléphone</h4>
      <p><a href="tel:+330123456789">+33 6 76 26 03 63</a></p>
    </div>
  </div>

  <!-- Google Map -->
  <div class="map-container d-flex justify-content-center">
    <iframe class="map-iframe"
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1010.2630981721296!2d6.079296631776423!3d49.338140209110996!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47952fa4e9698989%3A0xb7a1c45db6ae535f!2sBasket%20Club%20Hayange%20Marspich!5e0!3m2!1sfr!2sfr!4v1749807127178!5m2!1sfr!2sfr&zoom=14"
        allowfullscreen="" loading="lazy"></iframe>
  </div>
</section>


<?php include './assets/php/includes/hr_separator.php'; ?>




<section class="container-fluid my-5">
  <h2 class="text-center mb-4">❓ Foire Aux Questions</h2>
  
  <div class="accordion" id="faqAccordion">
    
    <!-- Question 1 -->
    <div class="accordion-item">
      <h2 class="accordion-header">
        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faq1">
          🔥 Comment puis-je rejoindre le BCHM ?
        </button>
      </h2>
      <div id="faq1" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
        <div class="accordion-body">
          C'est très simple ! Rendez-vous sur notre page <a href="./contact.php">Contact</a>, remplissez le formulaire, 
          et nous reviendrons vers vous rapidement pour l'inscription.
        </div>
      </div>
    </div>

    <!-- Question 2 -->
    <div class="accordion-item">
      <h2 class="accordion-header">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq2">
          🏀 Quels sont les niveaux disponibles au sein du club ?
        </button>
      </h2>
      <div id="faq2" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
        <div class="accordion-body">
          Le BCHM accueille des joueurs de tous âges et niveaux ! Nous avons des équipes allant des **U7** aux **seniors** 
          et participons aux compétitions départementales et régionales.
        </div>
      </div>
    </div>

    <!-- Question 3 -->
    <div class="accordion-item">
      <h2 class="accordion-header">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq3">
          🎟 Comment assister aux matchs du BCHM ?
        </button>
      </h2>
      <div id="faq3" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
        <div class="accordion-body">
          Les matchs se déroulent principalement au Gymnase de Hayange-Marspich. Consultez notre calendrier des rencontres 
          sur notre site ou suivez-nous sur les réseaux sociaux pour être informé !
        </div>
      </div>
    </div>

    <!-- Question 4 -->
    <div class="accordion-item">
      <h2 class="accordion-header">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq4">
          ⚡ Le club propose-t-il des stages ou entraînements spécifiques ?
        </button>
      </h2>
      <div id="faq4" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
        <div class="accordion-body">
          Oui ! Le BCHM organise régulièrement des **stages intensifs** et des entraînements spécifiques par catégorie 
          pour aider nos joueurs à progresser. Contactez-nous pour en savoir plus !
        </div>
      </div>
    </div>

  </div>
</section>



<?php include './assets/php/includes/hr_separator.php'; ?>




<section class="container-fluid my-5">
  <h2 class="text-center mb-4">🌟 Avis de nos membres</h2>

  <div id="avisCarousel" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-inner">
      
      <!-- Avis 1 -->
      <div class="carousel-item active">
        <div class="row justify-content-center">
          <div class="col-md-6 col-lg-3">
            <div class="card text-center p-3 shadow">
              <p>⭐⭐⭐⭐⭐</p>
              <h5>Jean Dupont</h5>
              <p>"Super club ! L’ambiance est top et les coachs sont très compétents."</p>
            </div>
          </div>
        </div>
      </div>

      <!-- Avis 2 -->
      <div class="carousel-item">
        <div class="row justify-content-center">
          <div class="col-md-6 col-lg-3">
            <div class="card text-center p-3 shadow">
              <p>⭐⭐⭐⭐⭐</p>
              <h5>Marie Lefevre</h5>
              <p>"Excellente expérience au BCHM, j'ai progressé rapidement !"</p>
            </div>
          </div>
        </div>
      </div>

      <!-- Avis 3 -->
      <div class="carousel-item">
        <div class="row justify-content-center">
          <div class="col-md-6 col-lg-3">
            <div class="card text-center p-3 shadow">
              <p>⭐⭐⭐⭐</p>
              <h5>Paul Bernard</h5>
              <p>"Des installations au top et une belle équipe !"</p>
            </div>
          </div>
        </div>
      </div>

      <!-- Avis 4 -->
      <div class="carousel-item">
        <div class="row justify-content-center">
          <div class="col-md-6 col-lg-3">
            <div class="card text-center p-3 shadow">
              <p>⭐⭐⭐⭐⭐</p>
              <h5>Sophie Martin</h5>
              <p>"Un vrai plaisir de faire partie du club, merci pour l’accueil !"</p>
            </div>
          </div>
        </div>
      </div>

    </div>

    <!-- Contrôles du slider -->
    <button class="carousel-control-prev" type="button" data-bs-target="#avisCarousel" data-bs-slide="prev">
      <span class="carousel-control-prev-icon"></span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#avisCarousel" data-bs-slide="next">
      <span class="carousel-control-next-icon"></span>
    </button>
  </div>
</section>

<?php
include 'assets/php/includes/hr_separator.php';
include 'assets/php/includes/newsletter_section.php';
include 'assets/php/includes/hr_separator.php'; 
include 'assets/php/includes/sponsors_section.php';
require_once 'assets/php/includes/footer.php';
?>

