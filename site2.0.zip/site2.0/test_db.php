<?php
try {
  $pdo = new PDO("mysql:host=localhost;dbname=site_php_crud;charset=utf8", 'root', '');
  echo "✅ Connexion réussie à la base !";
} catch (PDOException $e) {
  echo "❌ Erreur de connexion : " . $e->getMessage();
}
