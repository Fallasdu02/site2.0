<?php
require_once 'assets/php/includes/auth_check.php';
require_once 'assets/php/config/config.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
  header("Location: dashboard_users.php");
  exit;
}

$userId = intval($_GET['id']);

try {
  $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
  $stmt->execute([$userId]);

  // ✅ Message flash
  $_SESSION['flash_success'] = "✅ Utilisateur supprimé avec succès.";

} catch (PDOException $e) {
  // Tu peux loguer l’erreur ici si besoin
}

header("Location: dashboard_users.php");
exit;
