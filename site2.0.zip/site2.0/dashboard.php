<?php
session_start();
if (!isset($_SESSION['user'])) {
  header("Location: /site2.0/index.php#auth");
  exit;
}

require_once 'assets/php/includes/auth_check.php';
$pageTitle = "Dashboard";
$customStyle = "style_dashboard.css";
require_once 'assets/php/config/config.php';
require_once 'assets/php/includes/header.php';
// require_once 'assets/php/includes/navbar_dashboard.php';
require_once 'assets/php/includes/header.php';
require_once 'assets/php/includes/navbar.php';

// Compteurs dynamiques
try {
  $totalUsers = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
  $totalSubscribers = 0; // Remplacer par requête réelle sur table 'newsletter' si elle existe
  $totalMessages = 0;    // Idem, pour table 'messages' ou 'contact'
  $totalPosts = $pdo->query("SELECT COUNT(*) FROM articles")->fetchColumn();
} catch (PDOException $e) {
  $totalUsers = $totalSubscribers = $totalMessages = $totalPosts = "—";
}


?>

<div class="container-fluid">
  <div class="row">
    
    <!-- Sidebar -->
    <nav class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse border-end">
      <div class="position-sticky pt-3">
        <ul class="nav flex-column">
          <li class="nav-item"><a class="nav-link active" href="#">Accueil</a></li>
          <li class="nav-item"><a class="nav-link" href="dashboard_users.php">Utilisateurs</a></li>
          <li class="nav-item"><a class="nav-link" href="dashboard_articles.php">Articles</a></li>
          <li class="nav-item"><a class="nav-link text-danger" href="logout.php">Déconnexion</a></li>
        </ul>
      </div>
    </nav>

    <!-- Contenu principal -->
    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
      <div class="d-flex justify-content-between align-items-center py-3 border-bottom">
        <h1 class="h2">Bienvenue dans le back-office BCHM</h1>
      </div>

      <section class="mt-4">
        <p></p>
      </section>
      
      <section class="dashboard-stats mt-4">
        <div class="row g-4">
          <div class="col-sm-6 col-lg-3">
            <div class="card shadow-sm text-center">
              <div class="card-body">
                <h5 class="card-title">Utilisateurs</h5>
                <p class="display-6"><?= $totalUsers ?></p>
              </div>
            </div>
          </div>

          <div class="col-sm-6 col-lg-3">
            <div class="card shadow-sm text-center">
              <div class="card-body">
                <h5 class="card-title">Abonnés</h5>
                <p class="display-6"><?= $totalSubscribers ?></p>
              </div>
            </div>
          </div>

          <div class="col-sm-6 col-lg-3">
            <div class="card shadow-sm text-center">
              <div class="card-body">
                <h5 class="card-title">Messages</h5>
                <p class="display-6"><?= $totalMessages ?></p>
              </div>
            </div>
          </div>

          <div class="col-sm-6 col-lg-3">
            <div class="card shadow-sm text-center">
              <div class="card-body">
                <h5 class="card-title">Articles</h5>
                <p class="display-6"><?= $totalPosts ?></p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  </div>
</div>

<?php require_once 'assets/php/includes/footer.php'; ?>
