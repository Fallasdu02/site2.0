<?php
$pageTitle = "À propos";
require_once 'assets/php/includes/header.php';
require_once 'assets/php/includes/navbar.php';
?>

<?php include './assets/PHP/auth/auth_modal.php';?>
<?php include './assets/PHP/auth/alert_box.php';?>



<section class="container-fluid my-5">
  <h1 class="text-center mb-4">Bienvenue au Basket Club Hayange-Marspich !</h1>
  <p class="text-center lead">
    Depuis plus de deux décennies, le BCHM est le cœur battant du basket local, incarnant l'esprit de compétition, 
    de formation et de passion.
  </p>
  <p class="text-center">
    Hayange et ses quartiers associés – Marspich, Konacker et Saint Nicolas en Forêt – ont toujours vibré au rythme du ballon orange.
  </p>
  <p class="text-center">
    Aujourd’hui, nous sommes fiers de porter cet héritage et de continuer à écrire l’histoire du basket en Moselle.
  </p>

<?php include './assets/php/includes/hr_separator.php'; ?>



  <!-- SECTION HISTOIRE -->
  <div class="row align-items-center my-5">
    <div class="col-md-6">
      <h2 class="text-center">Notre histoire : <br> un héritage forgé sur les terrains</h2>
      <p class="text-center">Le BCHM est né de la fusion des différentes équipes locales qui ont marqué les générations de basketteurs depuis les années 1970. <br> D’abord réparti entre plusieurs clubs, l’évolution naturelle et la passion commune pour le basket ont conduit à la création d’une union forte et structurée, permettant à chaque joueur, des débutants aux seniors, de s’épanouir sous une même bannière. </p>
    </div>
    <div class="col-md-6">
      <img src="./assets/img/SMA.jpg" class="img-fluid rounded" alt="Histoire du BCHM">
    </div>
  </div>


<?php include './assets/php/includes/hr_separator.php'; ?>


<!-- SECTION AMBITION -->
<section id="ambitions" class="container-fluid my-5">
  <h2 class="text-center mt-5">Nos ambitions : Former, Gagner, Grandir</h2>
  <p class="text-center mb-4">Le club a connu une ascension fulgurante, notamment grâce à :</p>
  <div class="row">
    <div class="col-md-3 mb-3">
      <div class="card h-100 text-center" style="background-color: #e3f2fd;">
        <div class="card-body">
          <p class="card-text">
            ✅ <strong>La formation des jeunes</strong> : Des équipes benjamines aux seniors, nous veillons à offrir un encadrement de qualité.
          </p>
        </div>
      </div>
    </div>
    <div class="col-md-3 mb-3">
      <div class="card h-100 text-center" style="background-color: #fce4ec;">
        <div class="card-body">
          <p class="card-text">
            ✅ <strong>Des succès marquants</strong> : Champions de Moselle, titres en 3x3, montées en Excellence… notre palmarès est le reflet du travail et du dévouement de nos joueurs.
          </p>
        </div>
      </div>
    </div>
    <div class="col-md-3 mb-3">
      <div class="card h-100 text-center" style="background-color: #e8f5e9;">
        <div class="card-body">
          <p class="card-text">
            ✅ <strong>Un club en constante évolution</strong> : Plus de 200 licenciés, 12 équipes engagées et une reconnaissance régionale permettent de franchir des étapes majeures.
          </p>
        </div>
      </div>
    </div>
    <div class="col-md-3 mb-3">
      <div class="card h-100 text-center" style="background-color: #fff3e0;">
        <div class="card-body">
          <p class="card-text">
            🏆 <strong>20 ans du BCHM</strong> – La prochaine saison marquera un jalon historique pour notre club !
          </p>
        </div>
      </div>
    </div>
  </div>
</section>

<?php include './assets/php/includes/hr_separator.php'; ?>

  <!-- SECTION VALEURS -->
<section id="valeurs" class="container-fluid my-5">
  <h2 class="text-center mt-5">Nos valeurs : Bien plus qu’un club, une famille</h2>
  <div class="row">
    <div class="col-md-3 mb-3">
      <div class="card h-100 text-center" style="background-color: #dcedc8;">
        <div class="card-body">
          <h5 class="card-title">Excellence</h5>
          <p class="card-text">
            Se dépasser à chaque match, à chaque entraînement.
          </p>
        </div>
      </div>
    </div>
    <div class="col-md-3 mb-3">
      <div class="card h-100 text-center" style="background-color: #ffccbc;">
        <div class="card-body">
          <h5 class="card-title">Esprit d’équipe</h5>
          <p class="card-text">
            L’entraide et la solidarité, sur et hors du terrain.
          </p>
        </div>
      </div>
    </div>
    <div class="col-md-3 mb-3">
      <div class="card h-100 text-center" style="background-color: #d1c4e9;">
        <div class="card-body">
          <h5 class="card-title">Engagement</h5>
          <p class="card-text">
            Être actif dans la vie du club, en tant que joueur, coach ou bénévole
          </p>
        </div>
      </div>
    </div>
    <div class="col-md-3 mb-3">
      <div class="card h-100 text-center" style="background-color: #b3e5fc;">
        <div class="card-body">
          <h5 class="card-title">Passion</h5>
          <p class="card-text">
            Chaque joueur porte en lui l’amour du basket et l’envie de progresser.
          </p>
        </div>
      </div>
    </div>
  </div>
</section>

<?php include './assets/php/includes/hr_separator.php'; ?>


  <!-- SECTION FUTUR -->
<section id="futur" class="container-fluid my-5">
  <h2 class="text-center mt-5">Rejoignez-nous et écrivez l’histoire du basket avec nous !</h2>
  <div class="row">
    <div class="col-md-6 mb-3">
      <div class="card h-100 text-center" style="background-color: #e1f5fe;">
        <div class="card-body">
          <h5 class="card-title">L’avenir du BCHM s’annonce radieux</h5>
          <p class="card-text">
            Alors que nous atteignons des records de licenciés et multiplions les succès
          </p>
        </div>
      </div>
    </div>
    <div class="col-md-6 mb-3">
      <div class="card h-100 text-center" style="background-color: #e8f5e9;">
        <div class="card-body">
          <h5 class="card-title">Nouvelle générations</h5>
          <p class="card-text">
            Des générations de joueurs continuent à faire briller le club, et nous sommes impatients de célébrer les 20 ans de notre club lors de la prochaine saison.
          </p>
        </div>
      </div>
    </div>
  </div>
</section>


<?php include './assets/php/includes/hr_separator.php'; ?>


  <!-- SECTION COACHS - GRID & SLIDER -->
  <h2 class="text-center mt-5">Notre équipe d’encadrement</h2>
  
  <!-- MOBILE SLIDER -->
  <div id="coachCarousel" class="carousel slide d-lg-none" data-bs-ride="carousel">
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="./assets/img/coachu7.jpg" class="d-block w-100" alt="Coach U7">
        <p class="text-center">Nom du Coach – Entraîneur U7</p>
      </div>
      <div class="carousel-item">
        <img src="./assets/img/coachu11.jpg" class="d-block w-100" alt="Coach U11">
        <p class="text-center">Nom du Coach – Entraîneur U11</p>
      </div>
      <div class="carousel-item">
        <img src="./assets/img/coachu13.jpg" class="d-block w-100" alt="Coach U13">
        <p class="text-center">Nom du Coach – Entraîneur U13</p>
      </div>
      <div class="carousel-item">
        <img src="./assets/img/coachu15.jpg" class="d-block w-100" alt="Coach U15">
        <p class="text-center">Nom du Coach – Entraîneur U15</p>
      </div>
      <div class="carousel-item">
        <img src="./assets/img/u18G.jpg" class="d-block w-100" alt="Coach U18">
        <p class="text-center">Nom du Coach – Entraîneur U18</p>
      </div>
      <div class="carousel-item">
        <img src="./assets/img/SMA.jpg" class="d-block w-100" alt="Senior Masculin A">
        <p class="text-center">Nom du Coach – Entraîneur Senior Masculin A</p>
      </div>
      <div class="carousel-item">
        <img src="./assets/img/smB.jpg" class="d-block w-100" alt="Senior Masculin B">
        <p class="text-center">Nom du Coach – Entraîneur Senior Masculin B</p>
      </div>
      <div class="carousel-item">
        <img src="./assets/img/coachsf.jpg" class="d-block w-100" alt="Senior Feminin">
        <p class="text-center">Nom du Coach – Entraîneur Senior Feminin</p>
      </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#coachCarousel" data-bs-slide="prev">
      <span class="carousel-control-prev-icon"></span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#coachCarousel" data-bs-slide="next">
      <span class="carousel-control-next-icon"></span>
    </button>
  </div>

  <!-- GRID POUR TABLETTE & DESKTOP -->
  <div class="row d-none d-lg-flex">
    <div class="col-sm-6 col-md-3">
      <img src="./assets/img/coachu7.jpg" class="img-fluid rounded" alt="Coach U7">
      <p class="text-center">Nom du Coach – Entraîneur U7</p>
    </div>
    <div class="col-sm-6 col-md-3">
      <img src="./assets/img/coachu11.jpg" class="img-fluid rounded" alt="Coach U11">
      <p class="text-center">Nom du Coach – Entraîneur U11</p>
    </div>
    <div class="col-sm-6 col-md-3">
      <img src="./assets/img/coachu13.jpg" class="img-fluid rounded" alt="Coach U13">
      <p class="text-center">Nom du Coach – Entraîneur U13</p>
    </div>
    <div class="col-sm-6 col-md-3">
      <img src="./assets/img/coachu15.jpg" class="img-fluid rounded" alt="Coach U15">
      <p class="text-center">Nom du Coach – Entraîneur U15</p>
    </div>
    <div class="col-sm-6 col-md-3">
      <img src="./assets/img/coachu15filles.jpg" class="img-fluid rounded" alt="Coach U15 filles">
      <p class="text-center">Nom du Coach – Entraîneur U15 filles</p>
    </div>
    <div class="col-sm-6 col-md-3">
      <img src="./assets/img/u18G.jpg" class="img-fluid rounded" alt="Coach U18">
      <p class="text-center">Nom du Coach – Entraîneur U18</p>
    </div>
    <div class="col-sm-6 col-md-3">
      <img src="./assets/img/u21_bchm.jpg" class="img-fluid rounded" alt="Coach U21">
      <p class="text-center">Nom du Coach – Entraîneur U21</p>
    </div>
    <div class="col-sm-6 col-md-3">
      <img src="./assets/img/SMA.jpg" class="img-fluid rounded" alt="Coach seniors A">
      <p class="text-center">Nom du Coach – Entraîneur Senior Masculin</p>
    </div>
    <div class="col-sm-6 col-md-3">
      <img src="./assets/img/coachsmb.jpg" class="img-fluid rounded" alt="Coach seniors">
      <p class="text-center">Nom du Coach – Entraîneur Senior Masculin B</p>
    </div>
    <div class="col-sm-6 col-md-3">
      <img src="./assets/img/coachsf.jpg" class="img-fluid rounded" alt="Coach seniors">
      <p class="text-center">Nom du Coach – Entraîneur Senior Feminin</p>
    </div>

  </div>

 <?php include './assets/php/includes/hr_separator.php'; ?>


  <!-- SECTION SUCCÈS -->
  <section id="succes" class="container-fluid my-5">
    <h2 class="text-center mt-5">Nos succès</h2>
    <div class="row text-center my-4">
      <div class="col-md-4 mb-3">
        <div class="card h-100 text-center" style="background-color: #c8e6c9;">
          <div class="card-body">
            <h3 class="card-title">🏆 20+</h3>
            <p class="card-text">Années d’existence</p>
          </div>
        </div>
      </div>
      <div class="col-md-4 mb-3">
        <div class="card h-100 text-center" style="background-color: #fff9c4;">
          <div class="card-body">
            <h3 class="card-title">💪 200+</h3>
            <p class="card-text">Licenciés</p>
          </div>
        </div>
      </div>
      <div class="col-md-4 mb-3">
        <div class="card h-100 text-center" style="background-color: #ffe0b2;">
          <div class="card-body">
            <h3 class="card-title">🥇 12</h3>
            <p class="card-text">Équipes engagées</p>
          </div>
        </div>
      </div>
    </div>
    <div class="text-center mt-5">
      <a href="./contact.php" class="btn btn-success btn-lg">Nous rejoindre</a>
    </div>
  </section>

  
<?php
include 'assets/php/includes/hr_separator.php';
include 'assets/php/includes/newsletter_section.php';
include 'assets/php/includes/hr_separator.php'; 
include 'assets/php/includes/sponsors_section.php';
require_once 'assets/php/includes/footer.php';
?>