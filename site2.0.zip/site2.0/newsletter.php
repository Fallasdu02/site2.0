<?php
$pageTitle = "Newsletter";
require_once 'assets/php/includes/header.php';
require_once 'assets/php/includes/navbar.php';
?>


  <div class="container my-5">
    <!-- Message de confirmation (pop-up) -->
    <div id="successPopup" class="alert alert-success d-none" role="alert">
      <span class="success-icon">✔</span> Votre inscription est confirmée. Merci pour votre visite, nous vous tiendrons informée des actualités du BCHM.
    </div>
    
    <h1 class="text-center">Inscription Newsletter</h1>
    <p class="text-center">Inscrivez-vous à la newsletter et recevez les dernières mises à jour directement dans votre boîte mail !</p>
    
    <div class="row justify-content-center">
  <div class="col-md-8 col-lg-6">
    <form id="newsletterForm" class="needs-validation" novalidate>

      <!-- Email -->
      <div class="mb-3">
        <label for="newsletterEmail" class="form-label">Veuillez renseigner votre adresse email pour vous inscrire*</label>
        <input type="email" class="form-control" id="newsletterEmail" placeholder="EMAIL" required>
        <div class="form-text">Veuillez renseigner votre adresse, par ex. user@example.com</div>
      </div>
      
      <!-- Nom -->
      <div class="mb-3">
        <label for="newsletterNom" class="form-label">Entrez votre NOM</label>
        <input type="text" class="form-control" id="newsletterNom" placeholder="NOM" required>
        <div class="form-text">Veuillez renseigner votre nom complet</div>
      </div>
      
      <!-- Prénom -->
      <div class="mb-3">
        <label for="newsletterPrenom" class="form-label">Entrez votre PRENOM</label>
        <input type="text" class="form-control" id="newsletterPrenom" placeholder="Prénom" required>
        <div class="form-text">Veuillez renseigner votre prénom</div>
      </div>
    </div>
      
      <!-- Checkbox consentement -->
      <div class="form-check text-center mb-3">
        <input class="form-check-input" type="checkbox" id="newsletterConsent" required>
        <label class="form-check-label" for="newsletterConsent">
          J'accepte de recevoir vos e-mails et confirme avoir pris connaissance de votre politique de confidentialité et mentions légales.
        </label>
      </div>
      <p class="form-text text-center mb-3">Vous pouvez vous désinscrire à tout moment en cliquant sur le lien présent dans nos e-mails.</p>
      
      <!-- Bouton d'inscription -->
      <button type="submit" class="btn btn-success d-block mx-auto">S'inscrire</button>


      </form>
  </div>
</div>

  
  <!-- Bootstrap Bundle JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <!-- Votre JS spécifique -->
  <script src="/assets/js/newsletter.js"></script>

<?php
include 'assets/php/includes/sponsors_section.php';
require_once 'assets/php/includes/footer.php';
?>