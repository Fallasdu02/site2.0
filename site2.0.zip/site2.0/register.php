<?php
session_start();
$pageTitle = "Inscription";
$customStyle = null;
require_once './assets/php/includes/header.php';
require_once './assets/php/includes/navbar.php';
?>

<?php if (isset($_SESSION['auth_error'])): ?>
  <div class="alert alert-danger text-center"><?= $_SESSION['auth_error']; unset($_SESSION['auth_error']); ?></div>
<?php endif; ?>

<section class="container-fluid d-flex align-items-center justify-content-center" style="min-height: 100vh;">
  <div class="auth-modal show slide">

    <!-- Bouton retour -->
    <button type="button" class="close-btn-modal" onclick="event.stopPropagation(); window.location.href='index.php'">&times;</button>



    <!-- Register Form -->
    <div class="form-box register">
      <h2>S'inscrire</h2>
      <form action="assets/php/auth/auth_process.php" method="POST" class="needs-validation" novalidate>

        <div class="input-box">
          <input type="text" name="name" placeholder="Nom complet" required />
          <i class="bx bxs-user"></i>
          <div class="invalid-feedback">Veuillez entrer votre nom.</div>
        </div>

        <div class="input-box">
          <input type="email" name="email" placeholder="Email" required />
          <i class="bx bxs-envelope"></i>
          <div class="invalid-feedback">Veuillez entrer un email valide.</div>
        </div>

        <div class="input-box">
          <input type="password" name="password" placeholder="Mot de passe" required id="register-password" />
          <i class="bx bxs-lock"></i>
          <i class="toggle-password bx bx-show" data-target="#register-password"></i>
          <div class="invalid-feedback">Veuillez entrer un mot de passe.</div>
        </div>

        <div class="input-box">
          <input type="password" name="confirm_password" placeholder="Confirmez le mot de passe" required id="confirm-password" />
          <i class="bx bxs-lock"></i>
          <i class="toggle-password bx bx-show" data-target="#confirm-password"></i>
          <div class="invalid-feedback">Veuillez confirmer votre mot de passe.</div>
          <small id="password-match" class="text-danger ms-1 d-none">Les mots de passe ne correspondent pas.</small>
        </div>

        <button type="submit" name="register_btn" class="btn">S'inscrire</button>
      </form>

      <p>Déjà un compte ? <a href="login.php">Se connecter</a></p>
    </div>
  </div>
</section>
<?php
include 'assets/php/includes/hr_separator.php';
include 'assets/php/includes/newsletter_section.php';
include 'assets/php/includes/hr_separator.php'; 
include 'assets/php/includes/sponsors_section.php';
require_once 'assets/php/includes/footer.php';
?>