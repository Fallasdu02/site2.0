




<!-- Lorsqu’un utilisateur ajoute, modifie ou supprime un article,
 un message de confirmation s’affiche en haut de page : -->

<?php if (isset($_SESSION['flash_success'])): ?>
  <div class="alert alert-success">
    <?= $_SESSION['flash_success'] ?>
    <?php unset($_SESSION['flash_success']); ?>
  </div>
<?php endif; ?>

<!-- Fonction : améliore le feedback utilisateur après une action
(Create/Update/Delete). -->




<!-- Affichage dynamique des articles (PHP + base de données) -->

<?php foreach ($articles as $article): ?>
  <article>
    <h2><?= htmlspecialchars($article['titre']) ?></h2>
    <p><?= nl2br(htmlspecialchars($article['contenu'])) ?></p>
    <a href="article.php?id=<?= $article['id'] ?>">Lire la suite</a>
  </article>
<?php endforeach; ?>

<!-- Fonction : génère une liste d’articles depuis la base site_php_crud,
avec sécurisation anti-XSS (htmlspecialchars). -->





<!-- Affichage/masquage du mot de passe (JavaScript) -->

<input type="password" id="password" />
<button onclick="togglePassword()"><i class='bxr bx-eye-alt'></i> </button>

<script>
function togglePassword() {
  const input = document.getElementById("password");
  input.type = input.type === "password" ? "text" : "password";
}
</script>

<!-- Fonction : améliore l’ergonomie des formulaires de connexion ou d’inscription. -->



<!-- Active link dans la navigation (JavaScript) -->
<script>

    const links = document.querySelectorAll("nav a");
links.forEach(link => {
    if (link.href === window.location.href) {
        link.classList.add("active");
    }
});
</script>
<!-- Fonction : permet de surligner dynamiquement la page active dans le menu
 (amélioration UX/navigation). -->



<!-- Récupérer tous les articles (liste) -->
<?php
$stmt = $pdo->prepare("SELECT * FROM articles ORDER BY date_article DESC");
$stmt->execute();
$articles = $stmt->fetchAll(PDO::FETCH_ASSOC);
// <!-- Cette requête sélectionne tous les articles,
// triés du plus récent au plus ancien, pour affichage
// sur la page d’accueil ou l’admin. -->



//Vérifie les identifiants de connexion
$stmt = $pdo->prepare("SELECT * FROM utilisateur WHERE email_utilisateur = ?");
$stmt->execute([$email]);
$utilisateur = $stmt->fetch();
//requête qui sert à retrouver un utilisateur par son adresse mail et
// à vérifier son mot de passe haché via password_verify().


//Sélectionner un seul article via son ID
$id = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("SELECT * FROM articles WHERE id_article = ?");
$stmt->execute([$id]);
$article = $stmt->fetch(PDO::FETCH_ASSOC);
//affiche la page de détail d’un article en récupérant ses informations via son identifiant.



// Supprimer un commentaire
// php
$stmt = $pdo->prepare("DELETE FROM commentaire WHERE id_commentaire = ?");
$stmt->execute([$id]);
//Supprime un commentaire spécifique en fonction de son ID. Requête préparée = sécurité garantie.

?>