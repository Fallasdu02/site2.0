<?php
require_once 'assets/php/includes/auth_check.php';
require_once 'assets/php/config/config.php';

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=users_export.csv');

$output = fopen('php://output', 'w');
fputcsv($output, ['ID', 'Nom', 'Email', 'Inscrit le']);

try {
  $stmt = $pdo->query("SELECT id, prenom, email, created_at FROM users ORDER BY created_at DESC");
  while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    fputcsv($output, [
      $row['id'],
      $row['prenom'],
      $row['email'],
      date("d/m/Y", strtotime($row['created_at']))
    ]);
  }
} catch (PDOException $e) {
  fputcsv($output, ['Erreur lors de l’export : ' . $e->getMessage()]);
}

fclose($output);
exit;
