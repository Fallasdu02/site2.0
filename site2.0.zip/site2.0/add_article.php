<?php
require_once 'assets/php/includes/auth_check.php';
require_once 'assets/php/config/config.php';

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $titre     = trim($_POST['titre'] ?? '');
  $contenu   = trim($_POST['contenu'] ?? '');
  $categorie = $_POST['categorie'] ?? 'blog';

  if (empty($titre) || empty($contenu)) {
    $error = "Titre et contenu sont obligatoires.";
  } else {
    // Gestion de l'upload d'image
    $imageName = null;
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
      $fileTmpPath = $_FILES['image']['tmp_name'];
      $fileName    = $_FILES['image']['name'];
      $fileSize    = $_FILES['image']['size'];
      $fileType    = $_FILES['image']['type'];
      
      // Extraire l'extension du fichier
      $fileNameCmps = explode(".", $fileName);
      $fileExtension = strtolower(end($fileNameCmps));
      $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif'];

      if (in_array($fileExtension, $allowedExtensions)) {
        // Générer un nom unique pour l'image
        $newFileName = md5(time() . $fileName) . '.' . $fileExtension;
        // Définir le dossier de destination, par exemple "uploads/"
        $uploadFileDir = $_SERVER['DOCUMENT_ROOT'] . '/site2.0/uploads/';
        // Créer le dossier s'il n'existe pas
        if (!is_dir($uploadFileDir)) {
          mkdir($uploadFileDir, 0755, true);
        }
        $dest_path = $uploadFileDir . $newFileName;
        if (move_uploaded_file($fileTmpPath, $dest_path)) {
          $imageName = $newFileName;
        } else {
          $error = "Erreur lors du téléchargement de l'image.";
        }
      } else {
        $error = "Extension d'image non autorisée.";
      }
    }

    // S'il n'y a pas d'erreur pendant l'upload, on insère l'article dans la base
    if (!$error) {
      try {
        // La requête dispose d'un champ supplémentaire "image"
        $stmt = $pdo->prepare("INSERT INTO articles (titre, contenu, categorie, image, created_at) VALUES (?, ?, ?, ?, NOW())");
        $stmt->execute([$titre, $contenu, $categorie, $imageName]);

        $_SESSION['flash_success'] = "✅ Article publié avec succès.";
        header("Location: dashboard_articles.php");
        exit;
      } catch (PDOException $e) {
        $error = "Erreur : " . $e->getMessage();
      }
    }
  }
}
?>

<?php require_once 'assets/php/includes/header.php'; ?>

<div class="container py-5">
  <h2 class="mb-4">Ajouter un article</h2>

  <?php if ($error): ?>
    <div class="alert alert-danger"><?= $error ?></div>
  <?php endif; ?>

  <!-- N'oubliez pas l'attribut enctype pour l'upload -->
  <form method="POST" class="needs-validation" novalidate enctype="multipart/form-data">
    <div class="mb-3">
      <label for="titre" class="form-label">Titre</label>
      <input type="text" class="form-control" name="titre" id="titre" required>
    </div>

    <div class="mb-3">
      <label for="categorie" class="form-label">Catégorie</label>
      <select class="form-select" name="categorie" id="categorie" required>
        <option value="blog">Blog</option>
        <option value="match">Match</option>
        <option value="communiqué">Communiqué</option>
        <option value="evenement">Événement</option>
      </select>
    </div>

    <div class="mb-3">
      <label for="contenu" class="form-label">Contenu</label>
      <textarea name="contenu" id="contenu" class="form-control" rows="6" required></textarea>
    </div>

    <div class="mb-3">
      <label for="image" class="form-label">Image d'illustration</label>
      <input type="file" name="image" id="image" accept="image/*" class="form-control">
    </div>

    <button type="submit" class="btn btn-success">Publier</button>
    <a href="dashboard_articles.php" class="btn btn-secondary">↩️ Retour</a>
  </form>
</div>

<?php
require_once 'assets/php/includes/footer.php';
?>
